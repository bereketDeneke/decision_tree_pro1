//
//  ContentView.swift
//  Decision Tree
//  Author: Bereket Deneke
//  Created by NYUAD on 18/04/2023.
//
import SwiftUI
import WebKit

struct ContentView: UIViewRepresentable {
    let urlString: String

    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.configuration.preferences.javaScriptEnabled = true

        webView.configuration.defaultWebpagePreferences.allowsContentJavaScript = true
              return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        
        guard let url = URL(string: urlString) else { return }
        
          let websiteDataTypes = NSSet(array: [WKWebsiteDataTypeDiskCache, WKWebsiteDataTypeMemoryCache])
          let date = Date(timeIntervalSince1970: 0)
          WKWebsiteDataStore.default().removeData(ofTypes: websiteDataTypes as! Set<String>, modifiedSince: date) {
        
            uiView.load(URLRequest(url: url)
                            )
          }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(urlString: "https://bereketdeneke.github.io/decision_tree_pro1/")
    }
}
