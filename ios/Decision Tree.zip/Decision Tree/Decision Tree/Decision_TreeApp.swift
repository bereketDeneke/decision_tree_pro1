//
//  Decision_TreeApp.swift
//  Decision Tree
//
//  Created by NYUAD on 18/04/2023.
//

import SwiftUI

@main
struct Decision_TreeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(urlString:"https://bereketdeneke.github.io/decision_tree_pro1/")
        }
    }
}
